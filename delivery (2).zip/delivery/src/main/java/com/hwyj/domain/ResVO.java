package com.hwyj.domain;

import java.sql.Date;  

import lombok.Data;

@Data
public class ResVO {
	
	private String RES_CODE;
	private String RES_NAME;
	private String RES_INFO;
	private String DEL_PRICE;
	//private String RES_MENU_NAME;
	private String RES_MENU_PRICE;
	
}
